#include "JsonBuilder.h"
#include <string>
#include <iostream>
#include <sstream>

string JsonBuilder::str(int indent) const
{
    string str;

    #if(1)
    // string key = "greeting";
    // string values[] = { "hello", "world"};
    ostringstream oss;
    oss << "{ ";
        oss << key << ":";
        // if()
        oss << "[ ";
        for (auto w: values)
            oss <<"\"" << w << "\"" << ", ";
        oss << "]";

    oss << " }";
    #endif

    return str;
}