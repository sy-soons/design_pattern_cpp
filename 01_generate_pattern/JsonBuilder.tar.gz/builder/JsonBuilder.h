
#include <string>
#include <ostring>
#include <vector>

using namespace std;

/* string만 넣을 수 있는 json builder를 구현해야한다고 해보자. */
class JsonBuilder 
{
public:
    JsonBuilder(){};
private:
};

class JsonElement 
{
public:
    JsonElement(){};
    JsonElement(const string& key, const string& value)
        :key(key), value(value) { };
    JsonElement(const string& key, const string[] value)
        :key(key){ values. };
    
    string str(int indent = 0) const
    {

    }

private:
    string key;
    string[] values;
    vector<JsonElement> elements;
};