#include <iostream>
#include <string>
#include <sstream>
using namespace std;

int main()
{
    #if(0)
    string words[] = { "hello", "world"};
    ostringstream oss;
    oss << "<ul>";
    for (auto w: words)
        oss <<" <li>" << w << "</li>";
    oss << "</ul>";
    #endif
    #if(1)
    string key = "greeting";
    string values[] = { "hello", "world"};
    ostringstream oss;
    oss << "{ ";
        oss << key << ":";
        oss << "[ ";
        for (auto w: values)
            oss <<"\"" << w << "\"" << ", ";
        oss << "]";
    oss << " }";
    #endif

    cout << oss.str() << endl;
    return 0;
}